﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using NAudio.Wave;

namespace Part_1
{
    internal class Program
    {
        // Function for voice message
        static void VoiceMessage()
        {
            try
            {
                // Initialize the sound player with the path to your greeting audio
                SoundPlayer Greetings = new SoundPlayer("C:\\Users\\Dam!LoLa\\Desktop\\Part 1\\Part 1\\Part 1\\Voice message.wav");
                Greetings.PlaySync(); // Play the audio synchronously, ensuring the greeting finishes before continuing
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing greeting: " + ex.Message);
            }
        }

        // Function to display the ASCII logo for the "Cyber Security Awareness Bot"
        static void Logodisplay()
        {
            Console.Clear();
            string logo = @"                                                                    
            (          )                                            
            )\ (    ( /(   (  (                                     
          (((_))\ ) )\()) ))\ )(                                    
          )\__(()/(((_)\ /((_(()\                                   
         ((/ __)(_)| |(_(_))  ((_)                                  
          | (_| || | '_ / -_)| '_|                                  
           \(__\_, |_.__\___||_|                                    
            )\ )__/                   )                             
           (()/(  (       (  (  (  ( /((                            
            /(_))))\ (   ))\ )( )\ )\())\ )                         
           (_)) /((_))\ /((_(()((_(_))(()/(                         
           / __(_)) ((_(_))( ((_(_| |_ )(_))                        
         ( \__ / -_/ _|| || | '_| |  _| || |           (         )  
         )\|___(__(\__| \),(|_| |(|\__|\_, (         ( )\     ( /(  
      ((((_)(  )\))(  ( /( )(   ))\ (  |__))\(  (    )((_) (  )\()) 
       )\ _ )\((_)()\ )(_)(()\ /((_))\ ) /((_)\ )\  ((_)_  )\(_))/  
       (_)_\(__(()((_((_)_ ((_(_)) _(_/((_))((_((_)  | _ )((_| |_   
        / _ \ \ V  V / _` | '_/ -_| ' \)/ -_(_-(_-<  | _ / _ |  _|  
       /_/ \_\ \_/\_/\__,_|_| \___|_||_|\___/__/__/  |___\___/\__|  
                                                                    
            ";

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(logo);
            Console.ForegroundColor = ConsoleColor.Cyan;
            
            Console.ResetColor();
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();  // Wait for user input to proceed
        }

        // Function for user name and deco
        static void GreetingsAndUserinteraction()
        {
            // Ask for the user's name
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write("Please enter your name: ");
            Console.ResetColor();
            string clientName = Console.ReadLine();

            // name validation
            while (string.IsNullOrWhiteSpace(clientName))
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;

                Console.WriteLine("Please provide a valid name.");
                Console.ResetColor();
                Console.Write("Please enter your name: ");
                clientName = Console.ReadLine();
            }

            //  welcoming message to the user
            string DecorativeBorder = new string('*', 50);
            Console.WriteLine(DecorativeBorder);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nWelcome, {clientName}! I'm Here To Help You Stay Safe Online\n");
            Console.ResetColor();
            Console.WriteLine(DecorativeBorder);
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
            


            while (true)
            {
                Console.WriteLine($"\nbot:\n How can I assist you today?\n enter 'exit' to Close ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;

                Console.Write($"\n{clientName}:");
                Console.ResetColor();
                string clientInput = Console.ReadLine().ToLower();



                // To exit the app
                if (clientInput == "exit")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"\n{clientName}, Stay safe, Be safe");
                    Console.ResetColor();
                    break;
                }



                // Responses to basic cybersecurity-related user questions.
                else if (clientInput.Contains("how are you"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("bot: I'm just a bot, here to Help you stay safe online.");
                    Console.ResetColor();
                }
                else if (clientInput.Contains("what's your purpose") || clientInput.Contains("what is your purpose"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("bot: that will be helping you stay safe online.");
                    Console.ResetColor();
                }
                else if (clientInput.Contains("what can i ask you about"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("bot: Anything around cybersecurity questions! e.g: password safety, phishing, and safe browsing");
                    Console.ResetColor();
                }
                else if (clientInput.Contains("password safety"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nNice one!");
                    Console.WriteLine("bot: You simply must make use of long, unique passwords for your account/s.");
                    Console.ResetColor();
                }
                else if (clientInput.Contains("phishing"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nNice one!");
                    Console.WriteLine("bot: Phishing attacks involve unreal mails or sites that tricks you into sharing personal information.");
                    Console.WriteLine("bot: prevention will be to Always verify the sender's email address and avoid clicking on suspicious links.");
                    Console.ResetColor();
                }
                else if (clientInput.Contains("safe browsing"))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nNice one!");
                    Console.WriteLine("bot: For safe browsing, make use of a secure internet connection, avoid clicking on just any pop-ups.");
                    Console.ResetColor();
                }
                else if (string.IsNullOrWhiteSpace(clientInput))
                {
                    // validation for white space
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("bot: I didn't quite understand that. Could you rephrase?");
                    Console.ResetColor();
                }
                else
                {
                    // default response
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"bot: I'm here to help, {clientName}! I didn't quite understand that. Could you rephrase?");
                    Console.ResetColor();

                }

                // divider between questions
                Console.WriteLine("\n====================  ====================  ====================");
            }
            
        }

        //extention _part 2
        //___________________________________________________________________________________________________________________________

        //  keywords and responses
        static Dictionary<string, List<string>> keyRes = new Dictionary<string, List<string>>()
        {
            {"password", new List<string> {
                "Make use of strong, unique passwords",
                "Avoid personal details in passwords",
                "a password manager to store and generate complex passwords, can assist too" }
            },
            {"scam", new List<string> {
                "Be cautious of mails that request for personal information.",
                "take a moment to react to links or unkown links",
                "Dont be deulsional" }
            },
            {"privacy", new List<string> {
                "brouse through the privacy section on your social accounts.",
                "Decide who can access your personal information online.",
                " the Use of encryptions" }
            },
            {"phishing", new List<string> {
                "watch out for unwanted mails(unknow links)",
                "cross check any email addresses carefully before clicking anything .",
                "make use of  directly(main org site) website instead of clicking via the link" }
            }
        };

        // sentiment keywords
        static List<string> sentimentKeywords = new List<string> { "worried", "curious", "frustrated" };

        // context
        static string preTopic = "";
        static string ClientName = "";
        static string favTopic = "";







        static void Main(string[] args)
        {
            // Play greeting sound when application starts
            VoiceMessage();

            //displays the logo
            Logodisplay();

            //welcoming and interactive experience
            GreetingsAndUserinteraction();

            //extention _part 2
            //___________________________________________________________________________________________________________________________
            //  client's name 
            Console.Write("What is your name? ");
            ClientName = Console.ReadLine();

            Console.WriteLine($"Greetings , {ClientName}! Ask me about cybersecurity topics hints[ passwords, scams, privacy, or phishing.]");

            while (true)
            {
                Console.Write("\nYou: ");
                string clientInput = Console.ReadLine().ToLower(); 

                //To exit the chatbot
                if (clientInput == "exit")
                {
                    Console.WriteLine("Chatbot: Stay safe online! 👋");
                    break;
                }

                // Detect sentiment from input
                string sentiment = DetectSentiment(clientInput);
                if (!string.IsNullOrEmpty(sentiment))
                {
                    RespondToSentiment(sentiment);
                }

                // if keyword matches
                bool foundKeyword = false;

                // Loop  for a match
                foreach (var keyword in keyRes.Keys)
                {
                    if (clientInput.Contains(keyword))
                    {
                        preTopic = keyword; //store the previous topic
                        foundKeyword = true;

                        // If interestec save in favorite slot
                        if (clientInput.Contains("interested"))
                        {
                            favTopic = keyword;
                            Console.WriteLine($"Chatbot: Great! I'll remember that  {keyword}.");
                        }
                        else
                        {
                            // display random response due to the keyword
                            var responses = keyRes[keyword];
                            Random rnd = new Random();
                            Console.WriteLine("Chatbot: " + responses[rnd.Next(responses.Count)]);

                            // If in favorite slot
                            if (!string.IsNullOrEmpty(favTopic))
                            {
                                Console.WriteLine($"Chatbot: since you like {favTopic}, this tip will surely be  useful.");
                            }
                        }

                        break; // Exit one there is a match
                    }
                }

                // Follow-up questions
                if (!foundKeyword)
                {
                    // in cases of calrification on previous topic
                    if (clientInput.Contains("more") || clientInput.Contains("explain") || clientInput.Contains("details"))
                    {
                        if (!string.IsNullOrEmpty(preTopic) && keyRes.ContainsKey(preTopic))
                        {
                            var extraInfo = keyRes[preTopic];
                            Console.WriteLine("Chatbot: Here's more on that topic:");
                            foreach (var info in extraInfo)
                            {
                                Console.WriteLine($"- {info}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Chatbot: Could you clarify which section you want more calrification on?");
                        }
                    }
                    else
                    {
                        // invalid input
                        Console.WriteLine("Chatbot: I'm not sure I understand you. lets try that again");
                    }
                }
            }






        }

        // detect basic sentiment input
        static string DetectSentiment(string input)
        {
            foreach (string sentiment in sentimentKeywords)
            {
                if (input.Contains(sentiment))
                    return sentiment;
            }
            return "";
        }

        // sentiment response
        static void RespondToSentiment(string sentiment)
        {
            switch (sentiment)
            {
                case "worried":
                    Console.WriteLine("Chatbot:  completely understandable. Scammers can be very creative. Here are some tips to stay safe.");
                    break;
                case "curious":
                    Console.WriteLine("Chatbot: That's great!  Ask me anything, lets talk.");
                    break;
                case "frustrated":
                    Console.WriteLine("Chatbot: I'm here ,  just know you're doing right. Now Ask me anything.");
                    break;
            }
        }
    }
}
