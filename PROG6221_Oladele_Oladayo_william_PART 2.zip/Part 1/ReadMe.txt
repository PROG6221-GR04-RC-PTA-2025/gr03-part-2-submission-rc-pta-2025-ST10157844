welcome to cyber security bot

- open the file part 1.sln on your visual studio
- run the app
- in running the app youll be able to interacte with the console interface 
- follow the instruction presented on the console and enjoy! 